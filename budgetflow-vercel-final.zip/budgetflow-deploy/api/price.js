// api/price.js — Vercel Serverless Function
// Proxy per Yahoo Finance: risolve il problema CORS da browser.
// Chiamata dall'app: GET /api/price?ticker=IWDA.AS

export default async function handler(req, res) {
  // CORS headers — permette chiamate dall'app
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const { ticker } = req.query;

  if (!ticker) {
    return res.status(400).json({ error: 'ticker parameter required' });
  }

  // Ticker normalizzati per ETF europei comuni
  const tickerMap = {
    'IWDA':    'IWDA.AS',   // Euronext Amsterdam
    'EUNL':    'EUNL.DE',   // Xetra
    'CSPX':    'CSPX.L',    // London Stock Exchange
    'VWCE':    'VWCE.DE',   // Xetra
    'VUSA':    'VUSA.AS',   // Euronext Amsterdam
    'SWRD':    'SWRD.AS',   // Euronext Amsterdam
    'MEUD':    'MEUD.PA',   // Euronext Paris
    'AGGH':    'AGGH.MI',   // Borsa Italiana
  };

  const resolvedTicker = tickerMap[ticker.toUpperCase()] || ticker;

  const urls = [
    `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(resolvedTicker)}?interval=1d&range=2d`,
    `https://query2.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(resolvedTicker)}?interval=1d&range=2d`,
  ];

  let lastError = null;

  for (const url of urls) {
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; BudgetFlow/1.0)',
          'Accept': 'application/json',
        },
      });

      if (!response.ok) {
        lastError = `HTTP ${response.status}`;
        continue;
      }

      const data = await response.json();
      const result = data?.chart?.result?.[0];
      const meta = result?.meta;

      if (!meta || !meta.regularMarketPrice) {
        lastError = 'No price data in response';
        continue;
      }

      // Success — return standardized response
      return res.status(200).json({
        chart: {
          result: [{
            meta: {
              regularMarketPrice: meta.regularMarketPrice,
              chartPreviousClose: meta.chartPreviousClose || meta.previousClose,
              currency: meta.currency || 'EUR',
              exchangeName: meta.exchangeName || '',
              symbol: meta.symbol || resolvedTicker,
              regularMarketTime: meta.regularMarketTime,
            }
          }]
        }
      });

    } catch (err) {
      lastError = err.message;
      continue;
    }
  }

  // All attempts failed
  return res.status(502).json({
    error: 'Price not available',
    ticker: resolvedTicker,
    detail: lastError,
  });
}
